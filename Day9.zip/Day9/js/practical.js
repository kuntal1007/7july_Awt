function image()
{
    document.getElementById("box1").src="../css/jack_daniels_honey_logo_letters_93249_1366x768.jpg";
}